public interface Veggies {
    public String toString();
}
