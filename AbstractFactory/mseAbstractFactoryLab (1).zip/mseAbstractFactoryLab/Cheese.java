public interface Cheese {
    public String toString();
}
