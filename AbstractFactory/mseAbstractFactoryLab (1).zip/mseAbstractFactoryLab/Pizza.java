public abstract class Pizza {
	String name;

	Dough dough;
	Sauce sauce;
	Veggies veggies[];
	Cheese cheese;
	Pepperoni pepperoni;
	Clams clam;

	abstract void prepare();

	void bake() {
		System.out.println("Bake for 25 minutes at 350");
	}
	
	void cut() {
		System.out.println("Cutting pizza into slices");
	}
	
	void box() {
		System.out.println("Placing pizza in PizzaStore box");
	}
	

	void setName(String name) {
		this.name = name;
	}

	String getName() {
		return name;
	}

	public String toString() {
		StringBuilder result = new StringBuilder();
		if (dough != null) {
			result.append(dough.toString()).append(" style\n");
		}
		if (sauce != null) {
			result.append(sauce.toString()).append(" style\n");
		}
		if (cheese != null) {
			result.append(cheese.toString()).append(" style\n");
		}
		if (veggies != null && veggies.length > 0) {
			for (int i = 0; i < veggies.length; i++) {
				result.append(veggies[i].toString()).append(" style");
				if (i < veggies.length - 1) {
					result.append(", ");
				}
			}
			result.append("\n");
		}
		return result.toString();
	}
	
}
