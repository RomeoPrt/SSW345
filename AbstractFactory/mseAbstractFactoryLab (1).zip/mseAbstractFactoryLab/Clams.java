public interface Clams {
    public String toString();
}
