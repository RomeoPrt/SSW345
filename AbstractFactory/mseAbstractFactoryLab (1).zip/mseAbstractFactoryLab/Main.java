public class Main {
    public static void main(String[] args) {
        PizzaStore nyPizzaStore = new NYPizzaStore();
        System.out.println("___________CREATING NEW YORK CHEESE PIZZA___________");
        Pizza nyCheesePizza = nyPizzaStore.orderPizza("cheese");
        System.out.println("-" + nyCheesePizza.getName() + "-");
        System.out.println(nyCheesePizza);

        PizzaStore chicagoPizzaStore = new ChicagoPizzaStore();
        System.out.println("___________CREATING CHICAGO STYLE VEGGIE PIZZA___________");
        Pizza chicagoVeggiePizza = chicagoPizzaStore.orderPizza("veggie");
        System.out.println("-" + chicagoVeggiePizza.getName() + "-");
        System.out.println(chicagoVeggiePizza);
    }
}
